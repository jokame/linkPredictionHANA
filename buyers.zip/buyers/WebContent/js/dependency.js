function zero2D(rows, cols) {
  var zeroM = [], rw = [];
  while (cols--) rw.push(0);
  while (rows--) zeroM.push(rw.slice());
  return zeroM;
}

function drawDependency(){
	var url = "services/buyers.xsodata/BUYERS/?$format=json";

	var ring = {};
		ring.packageNames = [];
		ring.matrix = [];

	$.ajax({

		type: 'GET',
		url: url,

		success: function(data){

			edges = data.d.results;

			edges.forEach(function(edge){
				if ( ring.packageNames.indexOf(edge.BUYER.toString()) == -1 ) {
					ring.packageNames.push(edge.BUYER.toString());
				};
			});

			edges.forEach(function(edge){
				if ( ring.packageNames.indexOf(edge.SELLER.toString()) == -1 ) {
					ring.packageNames.push(edge.SELLER.toString());
				};
			});

			ring.matrix = zero2D(ring.packageNames.length, ring.packageNames.length);

			edges.forEach(function(edge){
				i = ring.packageNames.indexOf(edge.BUYER.toString());
				j = ring.packageNames.indexOf(edge.SELLER.toString());
				k = parseInt(edge.TOT);

				ring.matrix[0,i][j]=k;
			});

			var chart = d3.chart.dependencyWheel()
					.width(800)
				.padding(0.08);
				
			d3.select('#dWheel')
			  .datum(ring)
			  .call(chart);

		}

	});
}